<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShipmentLog extends Model
{
    protected $table = 'shipment_log';
    protected $guarded = [];
}
